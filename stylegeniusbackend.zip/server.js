const express = require('express');
const cors = require('cors');
const path = require('path');
const { spawn } = require('child_process');
const os = require('os');
const fs = require('fs').promises;
const logger = require('./logger');

const app = express();
const port = process.env.PORT || 3000;

// Enable CORS
app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Helper function to validate base64 image
const isValidBase64Image = (base64String) => {
    try {
        if (!base64String.match(/^data:image\/(png|jpeg|jpg);base64,/)) {
            return false;
        }
        return true;
    } catch (error) {
        return false;
    }
};

// Helper function to run Python script
const runPythonScript = async (base64Image, outputPath) => {
    return new Promise((resolve, reject) => {
        const pythonScript = path.join(__dirname, 'remove_bg.py');
        const process = spawn('python3', [
            pythonScript,
            base64Image,
            outputPath
        ]);
        
        let result = '';
        let errorOutput = '';
        
        process.stdout.on('data', (data) => {
            result += data.toString();
        });
        
        process.stderr.on('data', (data) => {
            errorOutput += data.toString();
            logger.error(`Python Error: ${data}`);
        });
        
        process.on('close', (code) => {
            if (code !== 0) {
                reject(new Error(`Process exited with code ${code}. Error: ${errorOutput}`));
                return;
            }
            resolve(result.trim());
        });
    });
};

app.post('/removeBackground', async (req, res) => {
    try {
        // Get the base64 image from the request body
        const base64Image = req.body.image;
        
        // Validate input
        if (!base64Image) {
            return res.status(400).json({
                success: false,
                error: 'No image provided'
            });
        }
        
        if (!isValidBase64Image(base64Image)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid image format. Please provide a base64 encoded image'
            });
        }

        // Create temporary file paths
        const tempDir = os.tmpdir();
        const outputPath = path.join(tempDir, `output_${Date.now()}.png`);

        // Process the image
        logger.info('Starting background removal process');
        const processedBase64 = await runPythonScript(base64Image, outputPath);
        
        // Clean up
        try {
            await fs.unlink(outputPath);
            await fs.unlink(path.join(__dirname, 'temp_input.png'));
        } catch (error) {
            logger.warn('Error cleaning up temporary files:', error);
        }

        // Return the processed image
        res.json({
            success: true,
            data: {
                processedImage: processedBase64
            }
        });
        
    } catch (error) {
        logger.error('Error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Internal server error'
        });
    }
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ status: 'ok' });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
}); 