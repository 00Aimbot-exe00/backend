#!/usr/bin/env python3

import sys
import base64
import io
from PIL import Image
from backgroundremover.bg import remove
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def process_base64_image(base64_string, output_path):
    try:
        # Decode base64 string
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
        
        image_data = base64.b64decode(base64_string)
        input_image = Image.open(io.BytesIO(image_data))
        
        # Save temporary input file
        temp_input = "temp_input.png"
        input_image.save(temp_input)
        
        # Remove background
        remove(temp_input, output_path)
        
        # Read the output file and convert to base64
        with open(output_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
        
        return encoded_string
        
    except Exception as e:
        logger.error(f"Error processing image: {str(e)}")
        raise

def main():
    if len(sys.argv) != 3:
        logger.error("Usage: remove_bg.py <base64_input> <output_path>")
        sys.exit(1)
        
    base64_input = sys.argv[1]
    output_path = sys.argv[2]
    
    try:
        result = process_base64_image(base64_input, output_path)
        print(result)  # Return base64 encoded result
        logger.info(f"Successfully processed image: {output_path}")
    except Exception as e:
        logger.error(f"Error processing image: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main() 