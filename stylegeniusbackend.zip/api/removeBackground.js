const express = require('express');
const cors = require('cors');
const { spawn } = require('child_process');
const fs = require('fs').promises;
const path = require('path');

// Create Express app
const app = express();

// Enable CORS
app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Helper function to run Python script
async function runPythonScript(imageBase64) {
  try {
    // Remove data:image/jpeg;base64, prefix if present
    const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');
    
    // Save image to temp file
    const inputPath = '/tmp/input.jpg';
    const outputPath = '/tmp/output.png';
    await fs.writeFile(inputPath, buffer);
    
    // Run Python script
    const pythonProcess = spawn('python3', [
      'remove_bg.py',
      '--input', inputPath,
      '--output', outputPath
    ]);
    
    return new Promise((resolve, reject) => {
      pythonProcess.on('close', async (code) => {
        if (code !== 0) {
          reject(new Error('Python script failed'));
          return;
        }
        
        try {
          const outputBuffer = await fs.readFile(outputPath);
          const base64Output = outputBuffer.toString('base64');
          resolve(base64Output);
        } catch (err) {
          reject(err);
        }
      });
      
      pythonProcess.on('error', reject);
    });
  } catch (err) {
    throw err;
  }
}

// API endpoint
app.post('/api/removeBackground', async (req, res) => {
  try {
    const { image } = req.body;
    if (!image) {
      return res.status(400).json({ error: 'No image provided' });
    }
    
    const processedImageBase64 = await runPythonScript(image);
    
    res.json({
      success: true,
      data: {
        processedImage: processedImageBase64
      }
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to process image'
    });
  }
});

// Export for Vercel
module.exports = app; 