const express = require('express');
const cors = require('cors');
const { spawn } = require('child_process');
const fs = require('fs').promises;
const path = require('path');

// Create handler function for Vercel
module.exports = async (req, res) => {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');

  // Handle OPTIONS request
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  // Only allow POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { image } = req.body;
    if (!image) {
      return res.status(400).json({ error: 'No image provided' });
    }
    
    // Remove data:image/jpeg;base64, prefix if present
    const base64Data = image.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');
    
    // Save image to temp file
    const inputPath = '/tmp/input.jpg';
    const outputPath = '/tmp/output.png';
    await fs.writeFile(inputPath, buffer);
    
    // Run Python script
    const pythonProcess = spawn('python3', [
      'remove_bg.py',
      '--input', inputPath,
      '--output', outputPath
    ]);
    
    const processedImage = await new Promise((resolve, reject) => {
      pythonProcess.on('close', async (code) => {
        if (code !== 0) {
          reject(new Error('Python script failed'));
          return;
        }
        
        try {
          const outputBuffer = await fs.readFile(outputPath);
          const base64Output = outputBuffer.toString('base64');
          resolve(base64Output);
        } catch (err) {
          reject(err);
        }
      });
      
      pythonProcess.on('error', reject);
    });

    res.json({
      success: true,
      data: {
        processedImage: processedImage
      }
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to process image'
    });
  }
}; 